# Offline creative brief starter kit

Open offline-prompt-kit.html in a modern browser. Load an example, edit JSON, validate it, then download JSON or Markdown. No server, account, API key, model or upload is required. Export before closing: the page does not save briefs.

Four modes: text-to-video, image-to-video, text-to-image, image-to-image. For image-to modes, reference is a reminder only, never an image read or upload. Use only authorized material when you later work online.

The tool, examples and original tutorials are MIT licensed. Website generation is a separate service requiring login, credits and availability. No unlimited free online generation is promised.

Website: https://freeaivideo.art
Source and CLI: https://github.com/cydiz/freeaivideo-prompt-kit
English tutorials: https://frequent-option-c81.notion.site/4170d247536b810a80eefc76c33806f5

No website backend, commercial template, production configuration, credentials or model weights are included.
